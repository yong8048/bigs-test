// src/components/ProtectedRoute.tsx
import React, { ReactNode, useEffect, useState } from "react";
import { Navigate } from "react-router-dom";

import { observer } from "mobx-react";
import { useAuthStore } from "../stores/AuthStoreContext";

interface ProtectedRouteProps {
  children: ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const authStore = useAuthStore();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = () => {
      const refreshToken = sessionStorage.getItem("refreshToken");

      if (refreshToken && !authStore.accessToken) {
        setTimeout(checkAuth, 100);
      } else {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, [authStore.accessToken]);

  if (isLoading) {
    return null;
  }

  if (!authStore.accessToken) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

export default observer(ProtectedRoute);
