interface ResCategory {
  value: string;
  label: string;
}

interface ResLogin {
  accessToken: string;
  refreshToken: string;
}
interface ResRefresh {
  accessToken: string;
  refreshToken: string;
}
